import { NextResponse, after } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { sendTemplateMessage } from '@/lib/whatsapp/meta-api'
import { decrypt } from '@/lib/whatsapp/encryption'
import type { SendTimeParams } from '@/lib/whatsapp/template-send-builder'
import { isMessageTemplate } from '@/lib/whatsapp/template-row-guard'
import {
  sanitizePhoneForMeta,
  isValidE164,
  phoneVariants,
  isRecipientNotAllowedError,
} from '@/lib/whatsapp/phone-utils'
import {
  checkRateLimit,
  rateLimitResponse,
  RATE_LIMITS,
} from '@/lib/rate-limit'
import {
  deliverBroadcast,
  type BroadcastPlan,
} from '@/lib/whatsapp/broadcast-core'

export const maxDuration = 60;

interface BroadcastResult {
  phone: string
  status: 'sent' | 'failed'
  whatsapp_message_id?: string
  error?: string
}

/**
 * Three input shapes are accepted:
 *
 *   BACKGROUND (dashboard wizard — creates broadcast + recipients
 *   client-side, then fires-and-forgets):
 *     { broadcastId: string }
 *
 *   NEW (preferred — supports per-recipient variable substitution):
 *     {
 *       recipients: Array<{ phone: string; params: string[] }>,
 *       template_name, template_language
 *     }
 *
 *   LEGACY (all phones receive the same params — kept so existing
 *   callers don't break):
 *     {
 *       phone_numbers: string[],
 *       template_params: string[],
 *       template_name, template_language
 *     }
 */
interface NewRecipient {
  phone: string
  /** Body variable values, one per {{N}}. Legacy field. */
  params?: string[]
  /**
   * Structured per-send values (header text variable, media URL
   * override, URL/COPY_CODE button values). When set, takes
   * precedence over `params` for the body too — see
   * sendTemplateMessage for the merge rules.
   */
  messageParams?: SendTimeParams
}

async function fetchCustomValueIndex(
  supabase: any,
  contactIds: string[],
): Promise<Map<string, Map<string, string>>> {
  const index = new Map<string, Map<string, string>>();
  if (contactIds.length === 0) return index;

  const PAGE = 500;
  for (let i = 0; i < contactIds.length; i += PAGE) {
    const slice = contactIds.slice(i, i + PAGE);
    const { data } = await supabase
      .from('contact_custom_values')
      .select('contact_id, custom_field_id, value')
      .in('contact_id', slice);

    for (const row of data ?? []) {
      const bucket = index.get(row.contact_id) ?? new Map<string, string>();
      bucket.set(row.custom_field_id, row.value ?? '');
      index.set(row.contact_id, bucket);
    }
  }
  return index;
}

export async function POST(request: Request) {
  try {
    const supabase = await createClient()

    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Per-user broadcast budget. Note: this limits how often a user
    // can *start* a campaign, not how many messages go out inside
    // one — the fan-out loop below runs without additional gating.
    const limit = checkRateLimit(`broadcast:${user.id}`, RATE_LIMITS.broadcast)
    if (!limit.success) {
      return rateLimitResponse(limit)
    }

    // Resolve the caller's account_id. whatsapp_config + templates
    // + broadcasts are all account-scoped post-multi-user, so the
    // old `.eq('user_id', user.id)` filters miss every row created
    // by a teammate.
    const { data: profile } = await supabase
      .from('profiles')
      .select('account_id')
      .eq('user_id', user.id)
      .maybeSingle()
    const accountId = profile?.account_id as string | undefined
    if (!accountId) {
      return NextResponse.json(
        { error: 'Your profile is not linked to an account.' },
        { status: 403 },
      )
    }

    const body = await request.json()

    // ── Background-send mode ──────────────────────────────────────
    // The dashboard wizard creates the broadcast + recipient rows
    // client-side, then sends { broadcastId } here. We build a
    // BroadcastPlan from the existing DB rows and fan out in after().
    if (typeof body.broadcastId === 'string' && !body.recipients && !body.phone_numbers) {
      const broadcastId = body.broadcastId as string

      // Fetch the broadcast row
      const { data: broadcast, error: bcErr } = await supabase
        .from('broadcasts')
        .select('*')
        .eq('id', broadcastId)
        .single()
      if (bcErr || !broadcast) {
        return NextResponse.json(
          { error: 'Broadcast not found' },
          { status: 404 },
        )
      }

      // Fetch WhatsApp config
      const { data: config, error: configErr } = await supabase
        .from('whatsapp_config')
        .select('*')
        .eq('account_id', accountId)
        .single()
      if (configErr || !config) {
        return NextResponse.json(
          { error: 'WhatsApp not configured.' },
          { status: 400 },
        )
      }

      // Load the template row for header/button components
      const { data: rawTemplateRow } = await supabase
        .from('message_templates')
        .select('*')
        .eq('account_id', accountId)
        .eq('name', broadcast.template_name)
        .eq('language', broadcast.template_language || 'en_US')
        .maybeSingle()
      const templateRow = rawTemplateRow && isMessageTemplate(rawTemplateRow)
        ? rawTemplateRow
        : null

      // Fetch all pending/failed recipients with their contacts
      const { data: recipients, error: recsErr } = await supabase
        .from('broadcast_recipients')
        .select('id, contact_id, status, variables, contact:contacts(*)')
        .eq('broadcast_id', broadcastId)
        .in('status', ['pending', 'failed'])
      if (recsErr || !recipients || recipients.length === 0) {
        return NextResponse.json(
          { error: 'No pending recipients found' },
          { status: 400 },
        )
      }

      // Resolve template variables from the broadcast row
      const templateVars = (broadcast.template_variables ?? {}) as Record<
        string,
        { type: string; value: string }
      >

      // Extract unique contact IDs to fetch custom values
      const contactIds = (recipients as any[])
        .map((r: any) => {
          const contactObj = Array.isArray(r.contact) ? r.contact[0] : r.contact;
          return contactObj?.id;
        })
        .filter(Boolean);

      const customValueIndex = await fetchCustomValueIndex(supabase, contactIds);

      // Build the planned array
      const planned = (recipients as any[])
        .filter((r: any) => r.contact && (Array.isArray(r.contact) ? r.contact[0]?.phone : r.contact?.phone))
        .map((r: any) => {
          const contactObj = Array.isArray(r.contact) ? r.contact[0] : r.contact;
          const customVals = customValueIndex.get(contactObj.id) ?? new Map();
          
          return {
            recipientRowId: r.id as string,
            phone: contactObj.phone as string,
            params: Object.keys(templateVars)
              .sort((a, b) => Number(a) - Number(b))
              .map((key) => {
                const v = templateVars[key];
                if (!v) return '';
                if (v.type === 'static') return v.value ?? '';
                if (v.type === 'field') {
                  const fieldMap: Record<string, string | undefined> = {
                    name: contactObj.name,
                    phone: contactObj.phone,
                    email: contactObj.email,
                    company: contactObj.company,
                  };
                  return fieldMap[v.value] ?? '';
                }
                if (v.type === 'custom_field') {
                  return customVals.get(v.value) ?? '';
                }
                if (v.type === 'csv_column') {
                  const rowVars = (r.variables ?? {}) as Record<string, string>;
                  return rowVars[v.value] ?? '';
                }
                return '';
              }),
          }
        })

      // Mark the broadcast as sending
      await supabase
        .from('broadcasts')
        .update({ status: 'sending' })
        .eq('id', broadcastId)

      // Reset failed recipients back to pending before retry
      await supabase
        .from('broadcast_recipients')
        .update({ status: 'pending', error_message: null })
        .eq('broadcast_id', broadcastId)
        .eq('status', 'failed')

      const plan: BroadcastPlan = {
        broadcastId,
        templateName: broadcast.template_name,
        templateLanguage: broadcast.template_language || 'en_US',
        phoneNumberId: config.phone_number_id,
        accessToken: decrypt(config.access_token),
        templateRow,
        planned,
        rejected: 0,
      }

      after(() => deliverBroadcast(supabase, plan))

      return NextResponse.json(
        { success: true, broadcastId, status: 'sending' },
        { status: 202 },
      )
    }

    // ── Inline-send mode (legacy) ─────────────────────────────────
    const {
      recipients: newRecipients,
      phone_numbers,
      template_name,
      template_language,
      template_params,
    } = body

    // Normalize to a list of {phone, params} regardless of shape.
    let recipients: NewRecipient[]
    if (Array.isArray(newRecipients) && newRecipients.length > 0) {
      recipients = newRecipients
    } else if (Array.isArray(phone_numbers) && phone_numbers.length > 0) {
      const shared: string[] = Array.isArray(template_params)
        ? template_params
        : []
      recipients = phone_numbers.map((phone: string) => ({
        phone,
        params: shared,
      }))
    } else {
      return NextResponse.json(
        {
          error:
            'Provide either `recipients` (preferred) or `phone_numbers` — must be a non-empty array',
        },
        { status: 400 }
      )
    }

    if (!template_name) {
      return NextResponse.json(
        { error: 'template_name is required' },
        { status: 400 }
      )
    }

    const { data: config, error: configError } = await supabase
      .from('whatsapp_config')
      .select('*')
      .eq('account_id', accountId)
      .single()

    if (configError || !config) {
      return NextResponse.json(
        {
          error:
            'WhatsApp not configured. Please set up your WhatsApp integration first.',
        },
        { status: 400 }
      )
    }

    const accessToken = decrypt(config.access_token)

    // Load the template row once so sendTemplateMessage can build
    // header + button components on each iteration. Loading inside
    // the loop would N+1 against Supabase for every recipient.
    // Guard against a malformed local row crashing every send in
    // the loop with the same opaque TypeError — fail loudly once.
    const { data: rawTemplateRow } = await supabase
      .from('message_templates')
      .select('*')
      .eq('account_id', accountId)
      .eq('name', template_name)
      .eq('language', template_language || 'en_US')
      .maybeSingle()
    if (rawTemplateRow && !isMessageTemplate(rawTemplateRow)) {
      return NextResponse.json(
        {
          error:
            'Template row is malformed locally — run "Sync from Meta" in Settings to repair it before broadcasting.',
        },
        { status: 500 },
      )
    }
    const templateRow = rawTemplateRow ?? null

    // Utility safeguard category check
    if (config.utility_only_safeguard) {
      if (!templateRow) {
        return NextResponse.json(
          { error: 'Campaign blocked: Utility-only safeguard is active, and the template must be synced from Meta first.' },
          { status: 400 }
        )
      }
      if (templateRow.category?.toLowerCase() !== 'utility') {
        return NextResponse.json(
          { error: `Campaign blocked: Utility-only safeguard is active, and this template is categorized as ${templateRow.category || 'MARKETING'}.` },
          { status: 400 }
        )
      }
    }

    // Resolve current wallet balance
    const { data: account } = await supabase
      .from('accounts')
      .select('wallet_balance')
      .eq('id', accountId)
      .single()
    let balance = Number(account?.wallet_balance ?? 0)
    const cost = templateRow?.category?.toLowerCase() === 'utility' ? 0.115 : 0.800

    const results: BroadcastResult[] = []
    let sentCount = 0
    let failedCount = 0

    for (const recipient of recipients) {
      // Check wallet balance before sending
      if (balance < cost) {
        const index = recipients.indexOf(recipient)
        const remaining = recipients.slice(index)
        for (const rem of remaining) {
          results.push({
            phone: rem.phone,
            status: 'failed',
            error: 'Insufficient wallet balance',
          })
          failedCount++
        }
        break
      }

      const sanitized = sanitizePhoneForMeta(recipient.phone)

      if (!isValidE164(sanitized)) {
        results.push({
          phone: recipient.phone,
          status: 'failed',
          error: 'Invalid phone number format',
        })
        failedCount++
        continue
      }

      // Retry with phone variants on "not in allowed list" so numbers
      // that differ only in a trunk-prefix 0 still reach recipients.
      const variants = phoneVariants(sanitized)
      let sentMessageId: string | null = null
      let lastError: string | null = null

      for (const variant of variants) {
        try {
          const result = await sendTemplateMessage({
            phoneNumberId: config.phone_number_id,
            accessToken,
            to: variant,
            templateName: template_name,
            language: template_language || 'en_US',
            template: templateRow ?? undefined,
            messageParams: recipient.messageParams,
            params: recipient.params ?? [],
          })
          sentMessageId = result.messageId
          lastError = null
          break
        } catch (error) {
          const errorMessage =
            error instanceof Error ? error.message : 'Unknown error'
          if (!isRecipientNotAllowedError(errorMessage)) {
            lastError = errorMessage
            break
          }
          lastError = errorMessage
          // retry with next variant
        }
      }

      if (sentMessageId) {
        results.push({
          phone: recipient.phone,
          status: 'sent',
          whatsapp_message_id: sentMessageId,
        })
        sentCount++
        balance -= cost

        // Update database balance
        await supabase
          .from('accounts')
          .update({ wallet_balance: balance })
          .eq('id', accountId)

        // Log transaction
        await supabase
          .from('wallet_transactions')
          .insert({
            account_id: accountId,
            user_id: user.id,
            amount: -cost,
            type: 'debit',
            description: `Dashboard Broadcast message sent to ${recipient.phone} (Template: ${template_name})`,
          })
      } else {
        console.error(
          `Failed to send broadcast to ${recipient.phone}:`,
          lastError
        )
        results.push({
          phone: recipient.phone,
          status: 'failed',
          error: lastError || 'Unknown error',
        })
        failedCount++
      }
    }

    return NextResponse.json({
      success: true,
      total: recipients.length,
      sent: sentCount,
      failed: failedCount,
      results,
    })
  } catch (error) {
    console.error('Error in WhatsApp broadcast POST:', error)
    return NextResponse.json(
      { error: 'Failed to process broadcast' },
      { status: 500 }
    )
  }
}
